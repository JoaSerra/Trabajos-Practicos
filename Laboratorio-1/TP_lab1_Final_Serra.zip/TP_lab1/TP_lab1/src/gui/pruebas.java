package gui;

import javax.swing.*;

public class pruebas {
    private JPanel prueba;
    private JButton button1;
    private JButton button2;
    private JTextField textField1;
    private JTextField textField2;
    private JTextField textField3;
    private JTextField textField4;
}
